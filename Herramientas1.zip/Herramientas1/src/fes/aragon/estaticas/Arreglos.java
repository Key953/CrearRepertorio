package fes.aragon.estaticas;

import fes.aragon.excep.IndiceFueraDeRango;
/**
 * 
 * @param <E>
 */
//@SuppressWarnings("unused")
public class Arreglos <E>{
	private int indice = 0;
	private final Object[] l;
	public Arreglos (int numeroElementos) {
		this.l = new Object[numeroElementos];
	}
	/**
	 * Metodo que inserta valores en el arreglo
	 * @param x
	 * @throws IndiceFueraDeRango xcepcion que sale cuando el arreglo 
	 * esta fuera del rango
	 */
	public void insertar (E x ) throws IndiceFueraDeRango{
		if(indice < l.length) {
			l[indice] = x;
			indice++;
		} else {
			throw new IndiceFueraDeRango("Indice fuera de rango");
		}
	}
	/**
	 * Metodo que localiza un valor en el arreglo
	 * @param x valor que se busca dentro del arreglo
	 * @return se retoma el -1 si no esta el valor en el arreglo
	 * si no se retorna el indice 
	 */
	public Integer localiza(E x) {
		for(int i = 0; i < l.length; i++) {
			if (l[i].equals(x)) {
				return i;
			}
		}
		return -1;
	}
	/**
	 * Metodo que recupera el elemento en el indice del arreglo
	 * @param p indice del arreglo
	 * @return retoma la posicion del valor anteriro como parametro
	 * @throws IndiceFueraDeRango xcepcion que sale cuando el arreglo 
	 * esta fuera del rango
	 */
	public E recupera(int p) throws IndiceFueraDeRango{
		if(p > l.length ||p < 0 ) {
			throw new IndiceFueraDeRango("Indice fuera de rango");
		}else {
			@SuppressWarnings("unchecked")
			final E e = (E)l[p];
			return e;
		}
	}
	/**
	 * Metodo que elimina un elemenot del arreglo
	 * @param p indice del elemento
	 * @throws IndiceFueraDeRango xcepcion que sale cuando el arreglo 
	 * esta fuera del rango
	 */
	public void suprime (int p)throws IndiceFueraDeRango{
		if(p > l.length ||p < 0 ) {
			throw new IndiceFueraDeRango("Indice fuera de rango");
		}else {
			l[p] = null;
		}
	}
	/**
	 * Metodo que da el elemento siguiente de la poscion del arreglo
	 * @param p indice del elemento
	 * @return E tomando la posicion anterior como parametro
	 * @throws IndiceFueraDeRango excepcion que sale cuando el arreglo 
	 * esta fuera del rango
	 */
	public E siguiente(int p) throws IndiceFueraDeRango{
		if(p == l.length ||p < -1 ) {
			throw new IndiceFueraDeRango("Indice fuera de rango");
		}
			@SuppressWarnings("unchecked")
			final E e = (E)l[p + 1];
			return e;
		}
	
	/**
	 * Metodo que da el elemento anterior de la posicion 
	 * @param p indice del elemento
	 * @return se retoma el integer como parametro
	 * @throws IndiceFueraDeRango excepcion que aparece cuando el arreglo
	 * esta fuera de rango
	 */
	public E anterior(int p) throws IndiceFueraDeRango{
		if(p == l.length -1 ||p < -1 ) {
			throw new IndiceFueraDeRango("Indice fuera de rango");
		}
			@SuppressWarnings("unchecked")
			final E e = (E)l[p - 1];
			return e;
		}
	/**
	 * Metodo que limpia el arreglo 
	 */
	public void limpiar() {
		for(int i = 0; i < l.length; i++) {
			l[i] = null;
		}
		//l= new Object[l.length];
	}
	/**
	 *Metodo que regresa el primer valor del arreglo 
	 */
	public E primero() {
		@SuppressWarnings("unchecked")
		final E e = (E)l[0];
		return e;
	}
	/** 
	 * Metodo que devuelve la longitud del arreglo 
	 * @return longitud del arreglo
	 */
	public Integer longitud() {
		return l.length;
	}
	/** 
	 * Metodo que imprime todos los valores del arreglo
	 */
	public void imprime() {
		for(int i = 0; i < l.length; i++) {
			System.out.println(l[i] + "");
		}
		System.out.println();
	}
	/**
	 * Metodo que asigna un valor en la posicion indicada
	 * @param p indica la posicion donde se encuentra el valor dentro del arreglo
	 * @param x valor que se inserta en la posicion p
	 * @throws IndiceFueraDeRango
	 */
	public void asignar(int p, E x) throws IndiceFueraDeRango{
		if(p > l.length -1 ||p < 0 ) {
			throw new IndiceFueraDeRango("Indice fuera de rango");
		}else {
			l[p] = x;
		}
	}
}
