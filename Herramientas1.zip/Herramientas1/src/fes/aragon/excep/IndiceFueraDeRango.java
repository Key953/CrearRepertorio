package fes.aragon.excep;
/**
 * CLase INdiceFueraDeRango
 */
public class IndiceFueraDeRango extends Exception {
	/**
	 * THe constant seriaVersiomUID
	 */
	private static final long serialVersionUID =1L;
	/**
	 * Instancia nueva indice fuera de rango
	 * @param msg
	 */
	public IndiceFueraDeRango(String msg) {
		super(msg);
	}
}
